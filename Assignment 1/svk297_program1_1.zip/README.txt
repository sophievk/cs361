UTEID: svk297;
FIRSTNAME: Sophie;
LASTNAME: Khounlo;
CSACCOUNT: sophiek;
EMAIL: s.khounlo@utexas.edu;

[Program 1]
There are 6 java files: 
In Subject.java, there are 5 helper methods that are used to set variables in the constructor and get variables in outside files. 
In Object.java,there are 6 helper methods that are used they same way as the methods in Subject.java. 
In InstructionObject.java, there are 8 helper methods and 3 different constructors. The methods are also used in the same way as the previous two java files. 
In ReferenceMonitor.java, I implemented 4 methods—isValid, executeWrite, executeRead, and checkInstruction–and the ObjectManager class–which also has 3 methods, createNewObject, read, and write. The ObjectManager keeps track of the objects and has a list of all the objects. The most important method is checkInstruction, which has two main steps: 1) it checks if the instruction is a write action then checks to see if the InstructionObject is a valid instruction. If it is valid, it will call executeWrite that checks to see if the subject has permission to write to the object, which will then call write in the ObjectManager to write to the object. 2) it checks if the instruction is a read action then checks to see if the InstructionObject is a valid instruction. If it is valid, it will call executeRead that checks to see if the subject has permission to read the object, which will then call read in the ObjectManager to read the object.
In SecureSystem.java, there are 3 methods, including the main method, and a List of subjects. createSubject creates a new subject and adds it to the list of subjects. printState prints out the state of the objects and subjects. In the main method, the subjects and objects are created. Then the file is parsed into InstructionObjects which get sent to the ReferenceMonitor.
To compile my program, you need to use "javac *.java". To run my program, you need to use "java SecureSystem instructionList".

[Finish]
I finished most of the assignment. There some bugs in executeRead and executeWrite in ReferenceMonitor.java, which doesn't allow me to read or write the objects. In both methods, they are returning a null pointer and not entering the for loop that I use to find the object in my objects list. I also did not start the project as early as I should have and ran out of time.

[Test Cases]
[Input of test 1]
write Hal HObj 
read Hal 
write Lyle LObj 10
read Hal LObj 
write Lyle HObj 20
write Hal LObj 200
read Hal HObj
read Lyle LObj
read Lyle HObj
foo Lyle LObj
Hi Lyle, This is Hal
The missile launch code is 1234567

[Output of test 1]
Reading from file: instructionList.txt

Bad Instruction
The current state is:
Lobj has value: 0
Hobj has value: 0
Lyle has recently read: 0
Hal has recently read: 0


Reading from file: instructionList.txt

Bad Instruction
The current state is:
Lobj has value: 0
Hobj has value: 0
Lyle has recently read: 0
Hal has recently read: 0


write: lobj
instruction: write
entered checkInstruction
entered write if
entered isValid
true
entered isValid
entered valid if
entered executeWrite
null
Exception in thread "main" java.lang.NullPointerException
	at ReferenceMonitor.executeWrite(ReferenceMonitor.java:71)
	at ReferenceMonitor.checkInstruction(ReferenceMonitor.java:95)
	at SecureSystem.main(SecureSystem.java:80)