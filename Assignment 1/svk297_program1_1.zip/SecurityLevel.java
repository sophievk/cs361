public class SecurityLevel{
	private int level;
	private SecurityLevel(int lvl) {
		this.level = lvl;
	}
	public static final SecurityLevel HIGH = new SecurityLevel(100);
	public static final SecurityLevel LOW = new SecurityLevel(0);

	public int getLevel(){
		return level;
	}
}