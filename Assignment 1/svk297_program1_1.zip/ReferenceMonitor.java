import java.util.List;
import java.util.ArrayList;
import java.util.Map;
import java.util.HashMap;

public class ReferenceMonitor{
	// private Map object_lvl;
	// private Map subject_lvl;
	private ObjectManager manager = new ObjectManager();

	class ObjectManager{
		public List<Object> objects =  new ArrayList<Object>();

		public void createNewObject(String name, SecurityLevel lvl){
			Object o = new Object(name, lvl);
			//object_level.put(name,lvl);
			objects.add(o);
		}

		//returns the value of the object
		public int read(String object){
			System.out.println("entered read");
			for(Object o : objects){
				if((o.getName()).compareTo(object)==0){
					return o.getVal();
				}
			}
			return 0;
		}

		//sets the value to the object
		public void write(String object, int val){
			System.out.println("entered write");
			for(Object o : objects){
				if((o.getName()).compareTo(object)==0){
					o.setVal(val);
				}
			}		
		}
	}

	public ReferenceMonitor(){
		// object_lvl = new HashMap<String, SecurityLevel>();
		// subject_lvl = new HashMap<String, SecurityLevel>();
	}

	public int executeRead(InstructionObject ins, Subject s){
		Object obj = new Object();
		for(Object o : manager.objects){
			if((o.getName().toLowerCase()).compareTo(ins.getObject())==0){
				obj = o;
			}
		}
		if(s.getLevel().getLevel() >= obj.getLevel().getLevel()){
			return manager.read(ins.getObject());
		}
		return 0;
	}

	public int executeWrite(InstructionObject ins, Subject s){
		System.out.println("entered executeWrite");
		Object obj = new Object();
		for(Object o : manager.objects){
			System.out.println("o: "+o.getName());
			if((o.getName().toLowerCase()).compareTo(ins.getObject())==0){
				System.out.println("entered if");
				obj = o;
			}
		}
		System.out.println(obj.getName());
		if((s.getLevel()).getLevel() <= (obj.getLevel()).getLevel()){
			manager.write(ins.getObject(), ins.getVal());
		}
		return 0;
	}

	public boolean isValid(InstructionObject ins){
		System.out.println("entered isValid");
		String act = ins.getAction();
		String sub = ins.getSubject();
		String obj = ins.getObject();
		int val = ins.getVal();
		if(act.compareTo("")==0 || sub.compareTo("")==0 || obj.compareTo("")==0 || val < 0){
			return false;
		}	
		return true;
	}	
	public int checkInstruction(InstructionObject ins, Subject s){
		System.out.println("entered checkInstruction");
		if((ins.getAction()).compareTo("write")==0){
			System.out.println("entered write if");
			System.out.println(isValid(ins));
			if(isValid(ins)){
				System.out.println("entered valid if");
				return executeWrite(ins, s);
			}
		}
		else if((ins.getAction()).compareTo("read")==0){
			if(isValid(ins)){
				return executeRead(ins, s);
			}
		}
		return 0;
	}	
}
