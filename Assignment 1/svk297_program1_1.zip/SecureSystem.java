import java.io.*;
import java.util.*;

public class SecureSystem{
	public static List<Subject> subjects = new ArrayList<Subject>();
	public static ReferenceMonitor monitor = new ReferenceMonitor();
	public static ReferenceMonitor.ObjectManager manager = monitor.new ObjectManager();

	public void createSubject(String name, SecurityLevel lvl){
		Subject s = new Subject(name, lvl);
		subjects.add(s);
	}

	public static void printState(String filename, InstructionObject ins){
		System.out.println("Reading from file: " + filename + "\n");
		if((ins.getAction()).compareTo("write")==0){
	 	System.out.println(ins.getSubject() + " writes value " + ins.getVal() + " to "+ ins.getObject());
		}
		else if((ins.getAction()).compareTo("read")==0){
			System.out.println(ins.getSubject() + " reads " + ins.getObject());
		}
		else{
			System.out.println("Bad Instruction");
		}
	 	System.out.println("The current state is:");
	 	for(Object o : manager.objects){
	 		System.out.println(o.getName()+" has value: "+o.getVal());
	 	}
		for(Subject s : subjects){
			System.out.println(s.getName()+" has recently read: "+s.getSTemp());
		}
		System.out.println("\n");
	}

	public static void main(String[] args) throws IOException{
		SecureSystem sys = new SecureSystem();

		SecurityLevel low = SecurityLevel.LOW;
		SecurityLevel high = SecurityLevel.HIGH;

		sys.createSubject("Lyle", low);
		sys.createSubject("Hal", high);

		manager.createNewObject("Lobj", low);
		manager.createNewObject("Hobj", high);

		if(0 < args.length){
			String filename = args[0];
			File file = new File(filename);
			Scanner in = new Scanner(file);
			String subject = "";
			String object = "";
			int val = 0;
			InstructionObject ins = new InstructionObject();
			while(in.hasNext()){
				String text = in.nextLine().toLowerCase();
				String[] line = text.split("\\s+");
				if(line[0].equals("write")){
					if(line.length == 4){
						subject = line[1];
						object = line[2];
						System.out.println("write: "+object);
						val = Integer.parseInt(line[3]);
						ins = new InstructionObject(line[0], subject, object, val);
					}
				}
				else if(line[0].equals("read")){
					if(line.length == 3){
						subject = line [1];
						object = line[2];
						ins = new InstructionObject(line[0], subject, object);
					}
				}
				else{
					ins = new InstructionObject();
				}
				for(Subject s : subjects){
					if((s.getName()).toLowerCase().compareTo(subject)==0){
						System.out.println("instruction: "+ins.getAction());
						monitor.checkInstruction(ins, s);
					}
				}
				printState(filename, ins);
					
			}
			in.close();
		}
	}
}