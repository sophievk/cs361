public class Subject{
	private String sname;
	private SecurityLevel slvl;
	private int temp;
	private StringBuilder bits;

	public Subject(String name, SecurityLevel lvl){
		setSName(name);
		setSLevel(lvl);
		temp = 0;
		bits = new StringBuilder();
	}

	//sets subject's name
	public void setSName(String n){
		this.sname = n;
	}

	//sets subject's security level
	public void setSLevel(SecurityLevel l){
		this.slvl = l;
	}

	//sets the temp value
	public void setTemp(int t){
		this.temp = t;
	}

	//returns subject's name
	public String getName(){
		return sname;
	}

	//returns subject's security level
	public SecurityLevel getLevel(){
		return slvl;
	}

	//returns temp
	public int getSTemp(){
		return temp;
	}

	//returns 0 if do not have 8 bits, otherwise returns byte
	public int run(){
		bits.append(temp);
		if(bits.length() == 8){
			int val = Byte.parseByte(bits.toString(), 2);
			bits.delete(0, bits.length());
			return val;
		}
		return 0;
	}
}